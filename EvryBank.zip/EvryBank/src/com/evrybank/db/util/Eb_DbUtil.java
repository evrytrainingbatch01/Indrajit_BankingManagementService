package com.evrybank.db.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Eb_DbUtil {
	public static Connection con = null;
	public static Statement st = null;
	public static Connection getConnectionDetails() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EVRYDB1","root","root");
			// create statement 
			
			
			
		}catch(Exception e) {
			
		}
		return con;
	}
}
