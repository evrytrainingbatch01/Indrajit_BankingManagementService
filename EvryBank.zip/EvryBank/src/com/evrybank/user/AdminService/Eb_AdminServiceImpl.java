package com.evrybank.user.AdminService;

import java.sql.SQLException;

import com.evrybank.Model.Eb_CustomersDetails;
import com.evrybank.user.AdminDao.Eb_AdminDao;
import com.evrybank.user.AdminDao.Eb_AdminDaoImpl;

public class Eb_AdminServiceImpl implements Eb_AdminService {

	Eb_AdminDao dao = new Eb_AdminDaoImpl();
	@Override
	public String addUser(Eb_CustomersDetails customerDetails) throws SQLException {
    String msg = null;
	int result = dao.insertCustomerDetails(customerDetails);
	if(result==0) 	
	    msg="customer object is created";
	else
		 msg="customers object is not created";
	
		return msg;
	}
	@Override
	public String deleteUser(String firstname) throws SQLException {
		String msg = null;
		int result = dao.deleteUser(firstname);
		if(result==0) 	
		    msg="customer object is deleted";
		else
			 msg="customers object is not created";		
			return msg;		
	}
}