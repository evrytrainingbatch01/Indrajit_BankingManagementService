package com.evrybank.user.AdminService;

import java.sql.SQLException;

import com.evrybank.Model.Eb_CustomersDetails;

public interface Eb_AdminService {
	public String addUser(Eb_CustomersDetails customerDetails) throws SQLException;
	public String deleteUser(String firstname) throws SQLException;
}
