package com.evrybank.user.CustomersService;

public interface Eb_CustomersService {

}
