package com.evrybank.user.CustomersService;

public class Eb_CustomerServiceImpl implements Eb_CustomersService {

}
