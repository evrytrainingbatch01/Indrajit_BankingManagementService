package com.evrybank.user.AdminDao;

import java.sql.SQLException;

import com.evrybank.Model.Eb_CustomersDetails;

public interface Eb_AdminDao {
	public int insertCustomerDetails(Eb_CustomersDetails customerDetails) throws SQLException;
	public int deleteUser(String firstname)throws SQLException;
}
