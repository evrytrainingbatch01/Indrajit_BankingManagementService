package com.evrybank.user.AdminDao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.evrybank.Model.Eb_CustomersDetails;
import com.evrybank.db.util.Eb_DbUtil;

public class Eb_AdminDaoImpl implements Eb_AdminDao {

	Connection con = Eb_DbUtil.getConnectionDetails();
	Statement st = null;
	int result=0;
	
	@Override
	public int insertCustomerDetails(Eb_CustomersDetails customerDetails) throws SQLException {
		if(con!=null)
			st = con.createStatement();
		
		   if(st!=null)                                                                 
				result=st.executeUpdate("insert into customersdetails values("+customerDetails.getFirstName()+","+
		                                                                       customerDetails.getLastName()+","+
						                                                       customerDetails.getAge()+","+
		                                                                       customerDetails.getCity()+","+
					                                                           customerDetails.getCountry()+","+
		                                                                       customerDetails.getMobileNo()+")");
		
		 
		   return result;
	}

	@Override
	public int deleteUser(String firstname) throws SQLException {
		if(con!=null)
			st = con.createStatement();
		if(st!=null)
			result=st.executeUpdate("Delete from customerdetails where firstname="+firstname);
		return result;		
	}

}
