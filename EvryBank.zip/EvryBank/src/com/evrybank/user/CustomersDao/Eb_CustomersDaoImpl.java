package com.evrybank.user.CustomersDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.evrybank.Model.Eb_CustomersDetails;
import com.evrybank.db.util.Eb_DbUtil;

public class Eb_CustomersDaoImpl implements Eb_CustomersDao {
	//private static final String INSERT_CUSTOMER_DETAILS="insert into customerlist values ";
	

	@Override
	public void addMoney() {
		
			
	}

	@Override
	public void sendMoney() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdrawMoney() {
		
	}
	

}
