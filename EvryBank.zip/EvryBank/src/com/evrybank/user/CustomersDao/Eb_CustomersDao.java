package com.evrybank.user.CustomersDao;

import com.evrybank.Model.Eb_CustomersDetails;

public interface Eb_CustomersDao {
	public void addMoney();
	public void sendMoney();
	public void withdrawMoney();
	
}
