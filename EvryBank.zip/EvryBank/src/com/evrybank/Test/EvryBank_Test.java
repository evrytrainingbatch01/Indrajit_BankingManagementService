package com.evrybank.Test;

import java.sql.SQLException;
import java.util.Scanner;

import com.evrybank.Model.Eb_CustomersDetails;
import com.evrybank.user.AdminService.Eb_AdminService;
import com.evrybank.user.AdminService.Eb_AdminServiceImpl;

public class EvryBank_Test {
	
	
	public static void main(String[] args) {
		
		Eb_AdminService service=new Eb_AdminServiceImpl();
		Eb_CustomersDetails customer = new Eb_CustomersDetails();
		
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter First Name:");
		String firstName = scn.nextLine();
		
		System.out.println("Enter Last Name:");
		String lastName = scn.nextLine();
		
		System.out.println("Enter Age:");
		int age = scn.nextInt();
		
		System.out.println("Enter city:");
		String city = scn.nextLine();
		scn.nextLine();
		
		System.out.println("Enter country:");
		String country = scn.nextLine();
		
		System.out.println("Enter Mobileno:");
		int mobileNo = scn.nextInt();
		
		System.out.println("Enter emailId:");
		String emailId = scn.nextLine();
		
		//Assignig value to customerDetails Object
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setAge(age);
		customer.setCity(city);
		customer.setCountry(country);
		customer.setMobileNo(mobileNo);
		customer.setEmailId(emailId);
		
	try {
		String result=	service.addUser(customer);
		String result1 = service.deleteUser(firstName);
		System.out.println("For insert:"+result);
		System.out.println("For Delete"+result1);
	} catch (Exception e) {
		e.printStackTrace();
	}		
	}
}
