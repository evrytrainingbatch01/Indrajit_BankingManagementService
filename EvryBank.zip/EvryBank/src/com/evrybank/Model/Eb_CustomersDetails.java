package com.evrybank.Model;

public class Eb_CustomersDetails {
	private String FirstName;
	private String LastName;
	private int    Age;
	private String City;
	private String Country;
	private int   MobileNo;
	private String EmailId;
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public int getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(int mobileNo) {
		MobileNo = mobileNo;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	
	@Override
	public String toString() {
		return "Eb_CustomersList [FirstName=" + FirstName + ", LastName=" + LastName + ", Age=" + Age + ", City=" + City
				+ ", Country=" + Country + ", MobileNo=" + MobileNo + ", EmailId=" + EmailId + "]";
	}
}